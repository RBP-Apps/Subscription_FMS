import Root from "./textarea.svelte";

export {
	Root,
	//
	Root as Textarea,
};
