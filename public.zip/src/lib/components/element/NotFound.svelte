<script lang="ts">
	import { navigate } from "$lib/router";
	navigate("/app/");
</script>
